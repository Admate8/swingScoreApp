---
title: SwingScore
emoji: 👁
colorFrom: red
colorTo: pink
sdk: docker
pinned: false
short_description: Appreciate your West Coast Swing competition progression
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
