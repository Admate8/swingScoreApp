# df_all_events <- openxlsx::read.xlsx(file.path("../Data Pipeline/Clean Data", "df_all_events.xlsx"), detectDates = TRUE)
# df_events     <- openxlsx::read.xlsx(file.path("../Data Pipeline/Clean Data", "df_events.xlsx"), detectDates = TRUE)
# df_comps      <- openxlsx::read.xlsx(file.path("../Data Pipeline/Clean Data", "df_competitions.xlsx"), detectDates = TRUE)
# df_subevents  <- openxlsx::read.xlsx(file.path("../Data Pipeline/Clean Data", "df_subevents.xlsx"), detectDates = TRUE)
# df_dancers    <- df_dancers <- openxlsx::read.xlsx(
#   file.path("../Data Pipeline/Clean Data", "df_dancers.xlsx")
# ) |>
#   dplyr::mutate(contestant_id = paste0(contestant, "_", wsdc_id)) |>
#   dplyr::left_join(
#     df_events |> dplyr::distinct(event_id, event_date, event_name),
#     by = "event_id"
#   )
# df_placement_counts <- openxlsx::read.xlsx(
#   file.path(here::here("../Data Pipeline/Clean Data"), "df_placement_counts.xlsx")
# )
# df_first_final <- openxlsx::read.xlsx(
#   file.path(here::here("../Data Pipeline/Clean Data"), "df_first_final.xlsx"),
#   detectDates = TRUE
# )
